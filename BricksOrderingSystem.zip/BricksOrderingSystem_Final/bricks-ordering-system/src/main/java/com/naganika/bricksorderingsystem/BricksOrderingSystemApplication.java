package com.naganika.bricksorderingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Naganika
 *
 */
@SpringBootApplication
public class BricksOrderingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BricksOrderingSystemApplication.class, args);
	}

}
