package com.naganika.bricksorderingsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.naganika.bricksorderingsystem.bean.Order;
import com.naganika.bricksorderingsystem.service.OrderService;

/**
 * @author Naganika
 *
 */
@RestController
public class BricksOrderingSystem {
	@Autowired
	OrderService orderService;
			
	@RequestMapping(method=RequestMethod.POST,value="/createOrder/{noOfBricks}")
	public Integer createOrder(@PathVariable Integer noOfBricks){
		return orderService.createOrder(noOfBricks);
		
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/getOrder/{orderReference}")
	public Order getOrder(@PathVariable Integer orderReference){
		return orderService.getOrder(orderReference);
		
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/getOrders")
	public List<Order> getOrders(){
		return orderService.getOrders();
		
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/updateOrder/{orderReference}/{noOfBricks}")
	public Integer updateOrder(@PathVariable Integer orderReference, @PathVariable Integer noOfBricks){
		return orderService.updateOrder(orderReference, noOfBricks);
		
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/fulfilOrder/{orderReference}")
	public Integer fulfilOrder(@PathVariable Integer orderReference){
		return orderService.fulfilOrder(orderReference);
		
	}

}
