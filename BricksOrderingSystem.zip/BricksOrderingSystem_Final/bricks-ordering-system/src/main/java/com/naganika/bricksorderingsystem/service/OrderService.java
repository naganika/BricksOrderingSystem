package com.naganika.bricksorderingsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.stereotype.Service;

import com.naganika.bricksorderingsystem.bean.Order;

/**
 * @author Naganika
 *
 */
@Service
public class OrderService {
	
	private List<Order> ordersList = new ArrayList<Order>();
	int sequence=0;
		
	public Integer createOrder(Integer noOfBricks) {
		Integer orderReference = generateNextNumber();	
		ordersList.add(new Order(orderReference,noOfBricks));
		return orderReference;
		
	}
	
	public Order getOrder(int orderReference) {
		try {
			return ordersList.stream().filter(x->x.getOrderReference().equals(orderReference)).findFirst().get();
		}catch(Exception e) {
			return null;// When order reference is not found
		}
		 
	}
	
	public List<Order> getOrders(){
		return ordersList;
	}
	
	public Integer updateOrder(Integer orderReference, Integer noOfBricks) {		
		for(int i=0; i<ordersList.size();i++) {
			Order order = ordersList.get(i);
			if (order.getOrderReference().equals(orderReference)) {	
				if(!order.isDispatched()) {
					order.setNoOfBricks(noOfBricks);
					ordersList.set(i, order);
				}else {
					// throw 404 error
					return Response.SC_BAD_REQUEST;
				}
			}
		}
		
		return orderReference;
	}
	
	public Integer fulfilOrder(Integer orderReference) {
		for(int i=0; i<ordersList.size();i++) {
			Order order = ordersList.get(i);
			if (order.getOrderReference().equals(orderReference)) {					
				order.setDispatched(true);
				ordersList.set(i, order);
				return orderReference;
			}
		}
		return Response.SC_BAD_REQUEST;
		//return error code404;		
	}
		
	private Integer generateNextNumber() {
		sequence++;
		return sequence;
	}

}
