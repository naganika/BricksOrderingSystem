package com.naganika.bricksorderingsystem.bean;

/**
 * @author Naganika
 *
 */
public class Order {
	
	private Integer orderReference;
	private Integer noOfBricks;
	private boolean isDispatched;
	
	public Order (Integer orderReference, Integer noOfBricks) {
		this.orderReference = orderReference;
		this.noOfBricks= noOfBricks;
	}	

	public Order() {
		// TODO Auto-generated constructor stub
	}

	public Integer getOrderReference() {
		return orderReference;
	}

	public void setOrderReference(Integer orderReference) {
		this.orderReference = orderReference;
	}

	public Integer getNoOfBricks() {
		return noOfBricks;
	}

	public void setNoOfBricks(Integer noOfBricks) {
		this.noOfBricks = noOfBricks;
	}

	public boolean isDispatched() {
		return isDispatched;
	}

	public void setDispatched(boolean isDispatched) {
		this.isDispatched = isDispatched;
	}
	
	
	
	

}
