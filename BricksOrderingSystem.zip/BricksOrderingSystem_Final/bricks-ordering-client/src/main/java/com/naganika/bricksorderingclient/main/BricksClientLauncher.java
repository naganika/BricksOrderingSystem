package com.naganika.bricksorderingclient.main;

import com.naganika.bricksorderingclient.service.RestCallingService;

/**
 * @author Naganika
 *
 */
public class BricksClientLauncher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestCallingService callingService = new RestCallingService();
		int noOfBricks= 5;		
		int orderReference = callingService.createOrder(noOfBricks);
		
		//int orderReference = 894; 
		String resp ="";
		resp= callingService.getOrder(orderReference);
		System.out.println(resp);
		resp= callingService.getOrder(999);
		System.out.println(resp);
		callingService.createOrder(5);
		callingService.createOrder(3);
		callingService.createOrder(7);
		resp = callingService.getOrders(); 
		System.out.println(resp);
		callingService.updateOrder(1,9);
		callingService.getOrder(orderReference);
		callingService.fulfilOrder(orderReference);
		callingService.getOrder(orderReference);
		

	}

}
