package com.naganika.bricksorderingclient.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Naganika
 *
 */
public class RestCallingService {
	
	
	public Integer createOrder(int noOfBricks) {
		
		String urlStr = "http://localhost:1234/createOrder/" + noOfBricks;
		String response = restCall(urlStr,"POST");	
		Integer orderReference= Integer.parseInt(response);
		return orderReference;
	}
	
	public String getOrder(int orderReference) {
		
		String urlStr = "http://localhost:1234/getOrder/" + orderReference;
		String response = restCall(urlStr,"GET");		
		return response;
	}
	
	public String getOrders() {
		
		String urlStr = "http://localhost:1234/getOrders";
		String response = restCall(urlStr,"GET");		
		return response;
	}
	
	public String updateOrder(int orderReference, int noOfBricks) {
		
		String urlStr = "http://localhost:1234/updateOrder/" + orderReference + "/" + noOfBricks;
		String response = restCall(urlStr,"PUT");		
		return response;
	}
	
	public String fulfilOrder(int orderReference) {
		
		String urlStr = "http://localhost:1234/fulfilOrder/" + orderReference;
		String response = restCall(urlStr,"PUT");		
		return response;
	}
	
	private String restCall(String urlStr, String reqMethod) {
		StringBuffer response = new StringBuffer();
		try {			
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(reqMethod);
			conn.setRequestProperty("Accept", "application/json");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
					BufferedReader in = new BufferedReader(new InputStreamReader(
						(conn.getInputStream())));
					String inputLine;					
					while ((inputLine = in.readLine()) != null) {
						response.append(inputLine);
					}
					in.close();
					conn.disconnect();	
					System.out.println("REST service call for URL "+ urlStr+ " is sucessful and the response is: " + response.toString());
					return response.toString();		
			}else {
				System.out.println("GET request not worked");
			}	

		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  }
		return response.toString();
	}
	
	

}
