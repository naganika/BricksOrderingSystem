package com.naganika.bricksorderingclient.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import com.naganika.bricksorderingclient.service.RestCallingService;
/**
 * @author Naganika
 *
 */
@TestMethodOrder(OrderAnnotation.class)
public class BricksOrderingClientTest {
	
	RestCallingService restService;
	
	@BeforeEach
	public void init() {
		restService = new RestCallingService();
	}
	
	@Test
	@Order(1)
	public void createOrderTest() {		
		assertEquals(1,restService.createOrder(5));//Create order with number of bricks as 5
		
	}
	
	@Test
	@Order(2)
	public void getOrderTest() {
		String expectedResult = "{\"orderReference\":1,\"noOfBricks\":5,\"dispatched\":false}";
		assertEquals(expectedResult,restService.getOrder(1)); // Get Order with order reference number as 1
	}
	
	@Test
	@Order(3)
	public void getInvalidOrderTest() {
		String expectedResult = "";
		assertEquals(expectedResult,restService.getOrder(999)); // Get Order with some invalid order reference number
	}
	
	@Test
	@Order(4)
	public void getOrdersTest() {
		restService.createOrder(5);
		restService.createOrder(3);
		restService.createOrder(7);
		String expectedResult = "[{\"orderReference\":1,\"noOfBricks\":5,\"dispatched\":false},{\"orderReference\":2,\"noOfBricks\":5,\"dispatched\":false},{\"orderReference\":3,\"noOfBricks\":3,\"dispatched\":false},{\"orderReference\":4,\"noOfBricks\":7,\"dispatched\":false}]";
		assertEquals(expectedResult,restService.getOrders()); // Get all Orders
	}
	
	@Test
	@Order(5)
	public void updateOrderTest() {		
		String expectedResult = "1";//order reference number
		assertEquals(expectedResult,restService.updateOrder(1,9)); // Update Order with order reference as 1 and no of bricks as 9
	}
	
	@Test
	@Order(6)
	public void fulfilOrderTest() {		
		String expectedResult = "1"; //order reference number
		assertEquals(expectedResult,restService.fulfilOrder(1)); // Update Order with dispatched as true
	}
	
	@Test
	@Order(7)
	public void fulfilInvalidOrderTest() {	
		String expectedResult = "400";
		assertEquals(expectedResult,restService.fulfilOrder(999)); // Fulfil Order with some invalid order reference number
	}
	
	@Test
	@Order(8)
	public void updateFullFilledOrderTest() {
		String expectedResult = "400";
		assertEquals(expectedResult,restService.updateOrder(1,20)); // update order which is already dispatched
	}

}
